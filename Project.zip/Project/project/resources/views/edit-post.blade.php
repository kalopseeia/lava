<!DOCTYPE html>
<html>
<head>
<title>Edit Data Form</title>
</head>
<body>
<a href="/post-list">back</a>
    <form method="POST" action="{{route('update')}}">
        @csrf
        <input type="hidden" name="id" value="{{$post->id}}">
        Firstname:
        <br>
        <input type="text" name="fname" value="{{$post->fname}}">
        <br>
        Lastname:
        <br>
        <input type="text" name="lname" value="{{$post->lname}}">
        <br>
        Contact:
        <br>
        <input type="number" name="contact" value="{{$post->contact}}">
        <br>
        Address:
        <br>
        <input type="text" name="address" value="{{$post->address}}">
        <br>
        <br>
        <input type="submit" value="Submit">
        <br>
       

    </form>
</body>
</html>