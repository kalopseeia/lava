<!DOCTYPE html>
<html>
<head>
<title>Save Data Form</title>
</head>
<body>
    <a href="/post-list">back</a>
    <form method="POST" action="{{route('save')}}">
        @csrf
        Firstname:
        <br>
        <input type="text" name="fname" placeholder="Input your name">
        <br>
        Lastname:
        <br>
        <input type="text" name="lname" placeholder="Input your Lastname">
        <br>
        Contact:
        <br>
        <input type="number" name="contact" placeholder="Input your Contact">
        <br>
        Address:
        <br>
        <input type="text" name="address" placeholder="Input your Address">
        <br>
        <br>
        <input type="submit" value="Submit">
        <br>
       

    </form>
</body>
</html>