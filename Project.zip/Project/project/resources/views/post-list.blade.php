<!DOCTYPE html>
<html>
<head>
<title>List Data Form</title>
    <style>
    table{
        border-collapse: collapse;
        width: 100%;
    }
    th,td{
        padding: 5px;
        border: 1px solid;
    }
    </style>
</head>
<body>
    <a href="{{route('add')}}">Add</a>
    <table>

    <tr>
        <th>ID</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Contact</th>
        <th>Address</th>
        <th>Action</th>
    </tr>

    @foreach($post as $post)
    <tr>
    <td>{{$post->id}}</td>
    <td>{{$post->fname}}</td>
    <td>{{$post->lname}}</td>
    <td>{{$post->contact}}</td>
    <td>{{$post->address}}</td>
    <td>
        <a href="/edit-post/{{$post->id}}">Edit</a>
        <a href="/delete-post/{{$post->id}}">Delete</a>
    </td>
    </tr>
    @endforeach

    </table>

</body>
</html>