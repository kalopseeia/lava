<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class mycontroller extends Controller
{
    //just go back 
    public function add()
    {
        return view('add-post');
    }
    //Save Data function 
    public function save(Request $request)
    {   
        DB::table('projects')->insert([
            'fname' =>$request->fname,
            'lname' =>$request->lname,
            'contact' =>$request->contact,
            'address' =>$request->address           
        ]);
        return back()->with('save','Data Saved');
    }

    //get the List of Data
    public function postlist()
    {
        $post = DB::table('projects')->get();
        return view('post-list',compact('post'));
    }

    //pressing the button and get the id 
    //and goto edit form
    public function edit($id)
    {
        $post = DB::table('projects')->where('id',$id)->first();
        return view('edit-post', compact('post'));
    }

    //update & save the data using id
    public function update(Request $request)
    {   
        DB::table('projects')->where('id',$request->id)->update([
            'fname' =>$request->fname,
            'lname' =>$request->lname,
            'contact' =>$request->contact,
            'address' =>$request->address           
        ]);
        return back()->with('update','Data Updated');
    }
    //delete the specific data using id
    public function deletepost($id)
    {
        DB::table('projects')->where('id',$id)->delete();
        return back()->with('delete','Data Deleted');
    }
    
}
