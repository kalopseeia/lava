<!DOCTYPE html>
<html>
<head>
<title>Save Data Form</title>
</head>
<body>
    <a href="/post-list">back</a>
    <form method="POST" action="<?php echo e(route('save')); ?>">
        <?php echo csrf_field(); ?>
        Firstname:
        <br>
        <input type="text" name="fname" placeholder="Input your name">
        <br>
        Lastname:
        <br>
        <input type="text" name="lname" placeholder="Input your Lastname">
        <br>
        Contact:
        <br>
        <input type="number" name="contact" placeholder="Input your Contact">
        <br>
        Address:
        <br>
        <input type="text" name="address" placeholder="Input your Address">
        <br>
        <br>
        <input type="submit" value="Submit">
        <br>
       

    </form>
</body>
</html><?php /**PATH C:\Users\Gem\Desktop\Project\project\resources\views/add-post.blade.php ENDPATH**/ ?>