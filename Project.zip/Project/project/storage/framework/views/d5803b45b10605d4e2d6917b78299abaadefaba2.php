<!DOCTYPE html>
<html>
<head>
<title>List Data Form</title>
    <style>
    table{
        border-collapse: collapse;
        width: 100%;
    }
    th,td{
        padding: 5px;
        border: 1px solid;
    }
    </style>
</head>
<body>
    <a href="<?php echo e(route('add')); ?>">Add</a>
    <table>

    <tr>
        <th>ID</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Contact</th>
        <th>Address</th>
        <th>Action</th>
    </tr>

    <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td><?php echo e($post->id); ?></td>
    <td><?php echo e($post->fname); ?></td>
    <td><?php echo e($post->lname); ?></td>
    <td><?php echo e($post->contact); ?></td>
    <td><?php echo e($post->address); ?></td>
    <td>
        <a href="/edit-post/<?php echo e($post->id); ?>">Edit</a>
        <a href="/delete-post/<?php echo e($post->id); ?>">Delete</a>
    </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>

</body>
</html><?php /**PATH C:\Users\Gem\Desktop\Project\project\resources\views/post-list.blade.php ENDPATH**/ ?>